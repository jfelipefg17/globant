package com.Globant.library.exceptions;

public class MyExceptions extends Exception{

  public MyExceptions(String s) {
    super(s);
  }
}
