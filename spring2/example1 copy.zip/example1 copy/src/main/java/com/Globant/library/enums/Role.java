package com.Globant.library.enums;

public enum Role {
  ADMIN,
  USER;
}
